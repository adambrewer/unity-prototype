﻿using System.Collections;
using UnityEngine;

public class DestroyByContact : MonoBehaviour
{


	public int scoreValue;

	void Start ()
	{
	}



    void OnTriggerEnter(Collider other)
{	
	if (other.tag == "asteroidLarge")
	{
		scoreValue = scoreValue + 20;
	}
	if (other.tag == "player")
	{
		return;
	}
        Destroy(other.gameObject);
        Destroy(gameObject);
    }
}